// Frontend script: send credit form to backend
const API_BASE = ""; // when deployed, replace with backend URL like https://your-backend.onrender.com

document.getElementById("creditForm").addEventListener("submit", async function(e){
  e.preventDefault();
  const f = e.target;
  const data = {
    fullname: f.fullname.value,
    passport: f.passport.value,
    phone: f.phone.value,
    income: Number(f.income.value)
  };
  try {
    const res = await fetch((API_BASE || "http://localhost:5000") + "/api/credit", {
      method: "POST",
      headers: {"Content-Type":"application/json"},
      body: JSON.stringify(data)
    });
    const json = await res.json();
    if (res.ok) {
      document.getElementById("formMsg").textContent = "Arizangiz yuborildi! Operator siz bilan bog'lanadi.";
      f.reset();
    } else {
      document.getElementById("formMsg").textContent = json.error || "Xatolik yuz berdi";
    }
  } catch (err) {
    document.getElementById("formMsg").textContent = "Serverga ulanib bo'lmadi.";
  }
});

// Pre-fill form when clicking product 'Nasiya olish'
document.querySelectorAll(".btn-nasiya").forEach(btn => {
  btn.addEventListener("click", ()=> {
    window.scrollTo({ top: document.querySelector(".credit-form").offsetTop - 20, behavior: "smooth" });
    // optionally populate something or show selected product
  });
});
