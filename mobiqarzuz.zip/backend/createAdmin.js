// createAdmin.js - one-time script to create initial admin user
const mongoose = require("mongoose");
const bcrypt = require("bcrypt");
require("dotenv").config();
const Admin = require("./models/Admin");

async function run() {
  if (!process.env.MONGO_URI) {
    console.error("Please create .env with MONGO_URI (or copy from .env.example).");
    process.exit(1);
  }
  await mongoose.connect(process.env.MONGO_URI);
  const email = "admin@mobiqarzuz.uz";
  const password = "Admin12345"; // change after creation
  const exists = await Admin.findOne({ email });
  if (exists) {
    console.log("Admin already exists:", email);
    process.exit(0);
  }
  const salt = await bcrypt.genSalt(10);
  const hash = await bcrypt.hash(password, salt);
  const a = new Admin({ email, password: hash, name: "Super Admin" });
  await a.save();
  console.log("Admin yaratildi:");
  console.log("  email:", email);
  console.log("  password:", password);
  console.log("\nPlease change the password after first login or edit createAdmin.js before running.");
  process.exit(0);
}

run().catch(e => { console.error(e); process.exit(1); });
