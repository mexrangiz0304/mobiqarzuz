const mongoose = require("mongoose");

const CreditFormSchema = new mongoose.Schema({
  fullname: { type: String, required: true },
  passport: { type: String, required: true },
  phone: { type: String, required: true },
  income: { type: Number, required: true },
  status: { type: String, default: "Kutilmoqda" },
  date: { type: Date, default: Date.now }
});

module.exports = mongoose.model("CreditForm", CreditFormSchema);
