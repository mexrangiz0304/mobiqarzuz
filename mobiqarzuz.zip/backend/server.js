const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const bodyParser = require("body-parser");
const bcrypt = require("bcrypt");
require("dotenv").config();

const Admin = require("./models/Admin");
const CreditForm = require("./models/CreditForm");

const app = express();
app.use(cors());
app.use(bodyParser.json());

const MONGO = process.env.MONGO_URI || "mongodb://localhost:27017/mobiqarzuz";
mongoose.connect(MONGO)
  .then(() => console.log("✅ MongoDB ulandi"))
  .catch(err => console.error("❌ MongoDB xato:", err));

// Public: submit credit application
app.post("/api/credit", async (req, res) => {
  try {
    const { fullname, passport, phone, income } = req.body;
    if (!fullname || !passport || !phone || !income) {
      return res.status(400).json({ error: "Maydonlar yetishmayapti" });
    }
    const form = new CreditForm({ fullname, passport, phone, income });
    await form.save();
    res.status(201).json({ message: "Ariza saqlandi!" });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Server xatoligi" });
  }
});

// Admin routes (simple - no JWT). Use createAdmin.js to create first admin.
app.post("/api/admin/register", async (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) return res.status(400).json({ error: "Email va parol kerak" });
    const exists = await Admin.findOne({ email });
    if (exists) return res.status(400).json({ error: "Admin allaqachon mavjud" });
    const hash = await bcrypt.hash(password, 10);
    const admin = new Admin({ email, password: hash });
    await admin.save();
    res.json({ message: "Admin yaratildi" });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Xatolik" });
  }
});

app.post("/api/admin/login", async (req, res) => {
  try {
    const { email, password } = req.body;
    const admin = await Admin.findOne({ email });
    if (!admin) return res.status(400).json({ error: "Admin topilmadi" });
    const ok = await bcrypt.compare(password, admin.password);
    if (!ok) return res.status(401).json({ error: "Parol noto'g'ri" });
    // Simple response. Frontend will store 'adminLoggedIn' flag in localStorage.
    res.json({ success: true, message: "Kirish muvaffaqiyatli" });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Server xatosi" });
  }
});

// Get all credit applications (for admin)
app.get("/api/credit", async (req, res) => {
  try {
    const forms = await CreditForm.find().sort({ date: -1 });
    res.json(forms);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Server xatosi" });
  }
});

// Approve or delete endpoints (simple)
app.put("/api/credit/:id", async (req, res) => {
  try {
    const { status } = req.body;
    const updated = await CreditForm.findByIdAndUpdate(req.params.id, { status }, { new: true });
    res.json(updated);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "O'zgartirish xatosi" });
  }
});

app.delete("/api/credit/:id", async (req, res) => {
  try {
    await CreditForm.findByIdAndDelete(req.params.id);
    res.json({ message: "Ariza o'chirildi" });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "O'chirish xatosi" });
  }
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Server ${PORT}-portda ishlayapti`));
