mobiqarzuz - Fullstack sample project (backend + frontend)

CONTENTS:
- backend/
  - server.js
  - models/Admin.js
  - models/CreditForm.js
  - createAdmin.js
  - package.json
  - .env.example
- frontend/
  - index.html
  - style.css
  - script.js
  - login.html
  - admin.html
  - assets/ (empty - add images if needed)

QUICK START (LOCAL):
1) Backend:
   - cd backend
   - cp .env.example .env  (and edit MONGO_URI)
   - npm install
   - node createAdmin.js    # creates first admin (edit email/password inside if needed)
   - node server.js
2) Frontend:
   - Open frontend/index.html in browser (or serve via static host)
   - Admin: open frontend/login.html and login with the admin created by createAdmin.js

NOTES:
- This project is a simple demonstration (no JWT). Admin login uses bcrypt and session state is stored in localStorage on client.
- For production: add HTTPS, protect admin routes, use JWT or httpOnly cookies, and secure environment variables.
